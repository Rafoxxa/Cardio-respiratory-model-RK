
%INSTRUCTIONS
% This script is the main module for solving an ODE (Ordinary Differential
% Equation) system. The main ODE solver is run in the 'run_ode' module. The
% script takes parameters, initial conditions, and optimization boundaries 
% from the 'load_global_easy' function.

% Functionality:
% The script can execute different types of simulations based on the 'type_of_input'
% parameter:
% 1. 'testing': Runs a small simulation (no longer than 20 seconds) to test 
%    the system's response to an input value of MRtCO2.
% 2. 'paper_simulation': Runs a complete simulation of 1260 seconds to observe 
%    the transient behavior over time.
% 3. 'deploy_results': Runs steady-state simulations, which means 10 different 
%    simulations with increasing values of MRtCO2 and picks the last value from 
%    a specific set of variables.
% 4. 'tiny paper simulation': Similar to 'paper_simulation' but with a simulation 
%    time of 0.1x (200 seconds).

% The input characteristics can be modified in the 'input_consumption()' function 
% within 'model_basic_vascular.m', which is only present in the 'tissue()' function.

% Global Variables:
% - 'all_global': Stores all the data used for delays and integration.

% Simulation Parameters:
% - 'type_of_input': Determines the type of simulation to run (1, 2, 3, or 4).
% - 'control_on': Toggle control mechanisms (1 = on, 0 = off).
% - 'only_plot': If set to 1, the script will only plot existing data without 
%   running new simulations.
% - 'dt': Time step for the simulation.
% - 'simulation_time': Total duration of the simulation, which varies based on 
%   'type_of_input'.

% Plotting Options:
% The script provides various plotting modes to visualize the results:
% - 'vars_to_show': Plots specified variables with their own axes.
% - 'multiple_to_show': Plots multiple variables against a common variable.
% - 'same_units': Plots variables with the same units.
% - 'interest_variables': Plots a predefined set of variables of interest.

% The script also includes various functions to structure and plot the simulation data.

% Load the necessary parameters, initial conditions, and time constants using
% the 'load_global_easy()' function. Ensure that the "variables_units.xlsx" file
% is present in the directory for reading the units of the variables.

%%  Instructions to Run:
% 1. Set the desired 'type_of_input'.
% 2. Toggle 'control_on' and 'only_plot' as needed.
% 3. Set the 'dt' and 'simulation_time' parameters.
% 4. Run the script to execute the simulation and plot the results based on 
%    the selected plotting mode.

%% 

%%Commands
rng(2);  
clc
clear -global delays_global
clear -global all_global
clear -global externals_global



%% Metasimulation parameters

%INPUT TYPE: (1) testing: Runs a small simulation (no longer than 20s) to test system's response to an input value of MRtCO2
%          , (2) paper_simulation: Run the whole simulation of 1260s to observe the transient behaviour over time
%            (3) deploy_results: Run the steady state simulation, that means 10 different simulations with increasing values of MRtCO2 and picks the last value form a specific set of variables
%            (4) tiny paper simulation: Is the same as (2) but the time is 0.1x.

%to change input characteristics go to '''input_consumption()''' function from model_basic_vascular.m  which exists only in '''tissue()''' function.

type_of_input = 1;
control_on = 1;
only_plot = 0;
dt = 0.01;
simulation_time = 10;   
if type_of_input == 2
    simulation_time = 1260;
elseif type_of_input == 4
    simulation_time = 200; 
end

model = @(varargin) model_basic_vascular(varargin{:});
run_ode_fun = @(varargin) run_ode(varargin{:});
structure_data_fun = @(varargin) structure_data(varargin{:});

%Loadings

[pars, init, taus] = load_global_easy();
pars('tau') = taus('tau_gases');
pars('dt') = dt; 
pars('type_of_input') = type_of_input;
units_table = readtable("variables_units.xlsx");
    

%global variables
%global delays_global;
global all_global;
%global externals_global;
%global dV_out;
%dV_out = struct();
%dV_out.values = [];
%dV_out.time_points = [];



%delays_global = zeros(length(init.values), length(taus.values), round(10 * simulation_time/dt) + 1) + 0;
all_global = zeros(15, round(10 * simulation_time/dt) + 1) + 0;  %This array saves all the data used for delays and for integration 
%externals_global = zeros(length(init.values), round(10 * simulation_time/dt) + 1) + 0;

if type_of_input == 3
[mrco2, vars] = deploy_papers_results('Sarmiento-2023-fig-3', run_ode_fun, structure_data_fun,...
                     'model', model, ...
                     'pars',  pars, ...
                     'init',  init, ... 
                     'taus',  taus, ...
                     'simulation_time', simulation_time, ...
                     'dt', dt, ...
                     'control_on', control_on);
end


if ~only_plot
     [t, x_dot, x_vars, x_keys, index] = run_ode(model, pars, init, taus, simulation_time, dt, control_on);
 end

 struct_vars = arrange_results(x_dot, x_vars, x_keys);
 
 plot_mode = ["vars_to_show","--","--", "--"];
 figure; 

 if ismember("vars_to_show", plot_mode)
    vars_to_show = ["P_sp", "MRtCO2"];  %With 2 options, both variables will be plotted with their own axis, with more, there will be just plot's superposition.
    plot_vars(t, struct_vars, vars_to_show, units_table); 
    figure; 
    %IF YOU WANT TO CONTINUE PLOTTING
    % vars_to_show = [" ", " "];
    % plot_vars(t, struct_vars, vars_to_show, units_table);
    % figure;
 elseif ismember("multiple_to_show", plot_mode)
    multiple_to_show = ["P_sa", "PbCO2", "PACO2", "PAO2"];
    common = "MRtCO2";
    plot_mutiple_vs_common(t, struct_vars,units_table, multiple_to_show, common);    
 elseif ismember("same_units", plot_mode)
    show_same_units_vars(t, struct_vars, units_table, 'blood_pressure');
 elseif ismember("interest_variables", plot_mode)
    show_interest_variables(t, struct_vars, units_table);
 end
 


%% FUNCTIONS

%ODE Solver
function [x_dot, x_vars, x_keys, index] = ode_solver(pars_static, pars, init, taus, t)
    %global hyperpars;
    global delays_global;
    global all_global;
    
    if pars_static
        %options = odeset('AbsTol',1e-8,'RelTol',1e-5);
        options = ddeset('AbsTol',1e-8,'RelTol',1e-5);
        %sol = ode23(@model_basic, [t(1), t(end)],init.values, options, pars, init.keys);
        sol = dde23(@model_basic, taus.values, init.values, [t(1), t(end)], options, pars, init.keys, taus.keys, 0);
        x_keys = init.keys;
        x_vars = deval(sol,t);
        index = dictionary(x_keys, [1:length(x_keys)]');
        %x_values = interp1(ode_t, sol, t, 'linear', 'extrap');   %change this to calling the model_basic with the state variables already computed
        
        %let's  get these xdots

        x_dot = zeros(size(x_vars));
        
        
        for i = 1:length(t)
            
            x_dot(:,i) = model_basic(t(i), x_vars(:,i), delays_global(:, :, round(t(i)/0.01) + 1), pars, init.keys, taus.keys, 0);
        end
        
    else
    
        options = odeset('AbsTol',1e-2,'RelTol',1e-2);        
        mo2 = pars('M_O2');
        for i = -10:20
            pars('M_O2') = mo2 * 10^(i/10); 
            sol= ode23(@model_basic, [t(1), t(end)],init.values, options, pars, init.keys);
            x_keys = init.keys;
            x_values = deval(sol,t);
            x_dep_M(i+11,:) = mean(x_values');
            %disp(i);
        end
    end
end

%Data structure
function results_table =  structure_data(x_values, xkeys)
    
    results_table = struct();

    for i = 1:length(xkeys)
        results_table.(xkeys{i}) = x_values(i, :);
    end
end

function struct_vars = arrange_results(x_dot, x_vars, x_keys) 
    struct_vars = structure_data(x_vars, x_keys);
    struct_dots = structure_data(x_dot, x_keys);

    struct_vars.dV = struct_dots.V;
    struct_vars.dV_total_rv = struct_dots.V_total_rv;
    struct_vars.dV_total_lv = struct_dots.V_total_lv;
    struct_vars.dV_total_ra = struct_dots.V_total_ra;
    struct_vars.dV_total_la = struct_dots.V_total_la;
    %Fake derivatives (this are created in oder to have the history acumulated of important internal variables that in esence are not state variables)
    struct_vars.Gaw = struct_dots.Gaw;
    struct_vars.aO2 = struct_dots.aO2;
    struct_vars.aCO2 = struct_dots.aCO2;
    struct_vars.Nt = struct_dots.Nt;    
    struct_vars.ddPaO2 = struct_dots.dPaO2;  
    
    struct_vars.TI = struct_dots.fake_TI;
    struct_vars.Tresp = struct_dots.fake_Tresp;  
    
    %Derived from operations
    struct_vars.HR = struct_vars.Theart.^-1;        

end

%Plotting
function plot_vars(t,rt, var_names,units_table)
    
    if length(var_names) == 2
    
       yyaxis left
       plot(t, real(rt.(var_names(1))));
       unit1 = find_unit(units_table, var_names(1));
       ylabel(unit1);

       yyaxis right
       plot(t, real(rt.(var_names(2))));
       unit2 = find_unit(units_table, var_names(2));
       ylabel(unit2)

    else
        for i = 1: length(var_names)
            plot(t, real(rt.(var_names(i))))
            %unit = find_unit(units_table, var_names(i));
            %ylabel(unit)
            hold on 
        end
       
    end 
    title('Plot');
    legend(var_names);
    legend(strrep(get(gca, 'Legend').String, '_', ' '));
    xlabel("time");
 
    
end

function plot_mutiple_vs_common(t, rt,units_table, multiple_to_show, common)
     
    for i=1:length(multiple_to_show)
        var_names_i = [multiple_to_show(i), common];
        plot_vars(t, rt, var_names_i, units_table);
        figure;
    end
end

function show_same_units_vars(t, struct_vars, units_table, label)

    if label == "blood_pressure"
        vars_to_show = ["P_sa", "P_sp"];
        plot_vars(t, struct_vars, vars_to_show, units_table);
        figure;
    elseif label == "O2"
        vars_to_show = ["P_1O2", "P_2O2", "P_3O2", "P_4O2", "P_5O2", "PAO2", "PaO2"];
        plot_vars(t, struct_vars, vars_to_show, units_table);
        figure;
    elseif label == "CO2"
        vars_to_show = ["P_1CO2", "P_2CO2", "P_3CO2", "P_4CO2", "P_5CO2", "PACO2", "PaCO2", "mean_PbCO2", "PvbCO2"];
        plot_vars(t, struct_vars, vars_to_show, units_table); 
        figure;  
    elseif label == "volume"
        vars_to_show = ['V_total_e_v', 'V_total_s_v', 'V_total_b_v', 'V_total_h_v', 'V_total_rm_v', 'V_total_am_v', 'V_total_vc', 'V_total_lv', 'V_total_la', 'V_total_rv', 'V_total_ra', 'V_total_pa', 'V_total_pp', 'V_total_pv'];
        plot_vars(t, struct_vars, vars_to_show, units_table);
        figure;
    elseif label == "flow"
        vars_to_show = ["Q_sa", "Q_pa"];
        plot_vars(t, struct_vars, vars_to_show, units_table);
        figure;
    end
    


end

function show_interest_variables(t, struct_vars, units_table)
    arteries = ["Q_sa", "P_sa"];
    atriums = ["V_total_ra", "V_total_la"];
    ventricles = ["V_total_lv", "V_total_rv"];
    lungs = ["V_total_pa", "V_total_pv", "V_total_pp"];
    systemic_venous = ["V_total_e_v","V_total_b_v", "V_total_rm_v", "V_total_am_v", "V_total_h_v", "V_total_s_v"];
    %CHANGE THE ONES YOU WANT

    
    
    plot_vars(t, struct_vars, arteries, units_table);
    title("Arteries");
    figure;      
    
    plot_vars(t, struct_vars, atriums, units_table);
    title("Atriums");
    figure;
    
    plot_vars(t, struct_vars, ventricles, units_table);
    title("Ventricles");
    figure;
    
    plot_vars(t, struct_vars, lungs, units_table);
    title("Lungs");
    figure;    

    plot_vars(t, struct_vars, systemic_venous, units_table);
    title("Systemic Venous");
    
    

end

function unit = find_unit(table, var)
    row_index = strcmp(table.Variable, var);
    unit = table.MeasureUnit{row_index};    
end
